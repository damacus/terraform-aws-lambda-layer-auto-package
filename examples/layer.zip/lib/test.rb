# frozen_string_literal: true
class TestExample
  def initialize

  end
end
